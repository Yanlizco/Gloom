# Gloom-Framework :: Linux Penetration Testing Framework
![Gloom-Framework](https://cdn.discordapp.com/attachments/326154623784321024/350411765844017152/gloom.png) 
## About Gloom
- Gloom is an Open-Source Security Framework
- This Framework was written in Python
### Donations?
- Every Dollar Counts and goes towards better Development
- Paypal -> https://paypal.me/joshDelta
## SSTec Tutorials Youtube
Special Thanks to SSTec Tutorials for making videos on GLoom.
- Video 1
https://youtu.be/R_0ErWoosFY
- Video 2
https://youtu.be/ZTQRT1rkS8w
- Video 3
https://youtu.be/ILXsZoSAajI
Make Sure to Check Them Out!
### Can I Fully Purchase This Framework(Take Ownership)?
 - Yes you can! If you want to purchase Gloom Framework,
 please contact -> gloomhelp5@gmail.com
#### Price?
- The Price for full ownership starts at $210.00
- For more info, please contact the email above.
### Install Gloom
#### First ``git clone``
  ``git clone https://github.com/joshDelta/Gloom-Framework.git``
#### Second ``cd``
  ``cd Gloom-Framework``
#### Third ``install``
  ``sudo python install.py``
#### Run The Program
  ``sudo python gloom.py``
## Operating Systems
- Gloom-Framework is Designed For Linux
### Will Gloom work on Windows?
- No, Gloom is not built for Windows
### Discord
https://discord.gg/9SFvVnD

